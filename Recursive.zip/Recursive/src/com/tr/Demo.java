package com.tr;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bar();
		System.out.println("I am in main");
	}
	static void bar() {
		DoWork();
		System.out.println("I am in Bar");
}
	static void DoWork() {
		DoMore();
		System.out.println("I am in Dowork");
	}
	static void DoMore() {
		System.out.println("I am in DoMore");
	}

}
