package com.tr;

public class RecursiveDemo {

	public static void main(String[] args) {
		foo(3);
	}
	
	static int  foo(int n) {
	if(n<1)
	return n;
	else
	foo(n-1);
	System.out.println("Hello"+n);
	return 0;
}

}
